<?php
include "include/header.php";
?>

<main>

<section class="inner_banner info_hub">
  <div class="container-medium">
    <h1 class="text-center text-white mb-4">Information hub</h1>
    <p>Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Etiam ut purus mattis </p>
  </div>
</section>

<section class="latest_blog">
  <div class="container-medium">
    <div class="row">
      <div class="col-md-6">
        <div class="blog_box">
          <div class="blog_img">
            <a href="event-detail.php"><img src="images/blog1.png" alt=""></a>
          </div>
          <h6>Event</h6>
          <h4><a href="event-detail.php">Vestibulum facilisis purus nec</a></h4>
          <p>Nam commodo suscipit quam. Sed hendrerit. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Phasellus viverra nulla ut metus variu.</p>
          <ul>
            <li>Jul 27, 2021</li>
            <li>18:30</li>
            <li>London</li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="blog_box">
          <div class="blog_img">
            <a href="insight-detail.php"><img src="images/blog2.png" alt=""></a>
          </div>
          <h6>News</h6>
          <h4><a href="insight-detail.php">Ut non enim eleifend felis</a></h4>
          <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
          <ul>
            <li>Jane More</li>
            <li>Jul 27, 2021 </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="blog_main">
  <div class="container-medium">
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">News</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Events & webinars</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Legal Guides</button>
      </li>
    </ul>
    <div class="tab-content" id="pills-tabContent">
      <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
        <div class="row mt-5">
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog3.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent ac massa at ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail2.php"><img src="images/blog4.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail2.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="event-detail.php"><img src="images/blog6.png" alt=""></a>
              </div>
              <h6>Event</h6>
              <h4><a href="event-detail.php">Maecenas egestas arcu quis ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jul 27, 2021</li>
                <li>18:30</li>
                <li>Nottingham</li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog7.png" alt=""></a>
              </div>
              <h6>Webinar</h6>
              <h4><a href="insight-detail.php">Donec quam felis ultricies</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail2.php"><img src="images/blog8.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail2.php">Ut non enim eleifend felis </a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog9.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent nonummy mi in</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog10.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="pagination">
          <ul>
            <li><a href="#"><img src="images/left-black.svg" alt=""></a></li>
            <li><a href="#">1</a></li>
            <li class="active">2</li>
            <li><a href="#">3</a></li>
            <li><a href="#">...</a></li>
            <li><a href="#">20</a></li>
            <li><a href="#"><img src="images/right-black.svg" alt=""></a></li>
          </ul>
        </div>
      </div>
      <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
        <div class="row mt-5">
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog3.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent ac massa at ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog4.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="event-detail.php"><img src="images/blog6.png" alt=""></a>
              </div>
              <h6>Event</h6>
              <h4><a href="event-detail.php">Maecenas egestas arcu quis ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jul 27, 2021</li>
                <li>18:30</li>
                <li>Nottingham</li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog7.png" alt=""></a>
              </div>
              <h6>Webinar</h6>
              <h4><a href="insight-detail.php">Donec quam felis ultricies</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog8.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Ut non enim eleifend felis </a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog9.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent nonummy mi in</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog10.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="pagination">
          <ul>
            <li><a href="#"><img src="images/left-black.svg" alt=""></a></li>
            <li><a href="#">1</a></li>
            <li class="active">2</li>
            <li><a href="#">3</a></li>
            <li><a href="#">...</a></li>
            <li><a href="#">20</a></li>
            <li><a href="#"><img src="images/right-black.svg" alt=""></a></li>
          </ul>
        </div>
      </div>
      <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
        <div class="row mt-5">
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog3.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent ac massa at ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog4.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="event-detail.php"><img src="images/blog6.png" alt=""></a>
              </div>
              <h6>Event</h6>
              <h4><a href="event-detail.php">Maecenas egestas arcu quis ligula</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jul 27, 2021</li>
                <li>18:30</li>
                <li>Nottingham</li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog7.png" alt=""></a>
              </div>
              <h6>Webinar</h6>
              <h4><a href="insight-detail.php">Donec quam felis ultricies</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog8.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Ut non enim eleifend felis </a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog9.png" alt=""></a>
              </div>
              <h6>News</h6>
              <h4><a href="insight-detail.php">Praesent nonummy mi in</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog10.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Donec id justo</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021 </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="blog_box">
              <div class="blog_img">
                <a href="insight-detail.php"><img src="images/blog5.png" alt=""></a>
              </div>
              <h6>Legal Guides</h6>
              <h4><a href="insight-detail.php">Maecenas ullamcorper dui et placerat</a></h4>
              <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
              <ul>
                <li>Jane More</li>
                <li>Jul 27, 2021</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="pagination">
          <ul>
            <li><a href="#"><img src="images/left-black.svg" alt=""></a></li>
            <li><a href="#">1</a></li>
            <li class="active">2</li>
            <li><a href="#">3</a></li>
            <li><a href="#">...</a></li>
            <li><a href="#">20</a></li>
            <li><a href="#"><img src="images/right-black.svg" alt=""></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      