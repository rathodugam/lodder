<?php
include "include/header.php";
?>

<main>

<section class="about_section second">
  <div class="row align-items-center">
    <div class="col-md-6">
      <div class="about_section_text">
        <h1 class="text-white">Careers at Lodders</h1>
        <p class="text-white">Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aliquam lobortis. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Praesent egestas neque eu enim.</p>
        <p class="text-white">Fusce neque. Morbi ac felis. Phasellus gravida semper nisi. Vivamus euismod mauris. Pellentesque ut neque.</p>
        <a href="#" class="btn_pink2">Why work for Lodders</a>
      </div>
    </div>
    <div class="col-md-6">
      <div class="about_section_img">
        <img src="images/about-img.png" alt="">
      </div>
    </div>
  </div>
</section>

<section class="careers_menu">
  <div class="container-large">
    <ul>
      <li><a href="#">Vacancies</a></li>
      <li><a href="#">Trainee Solicitors</a></li>
      <li><a href="#">Business Support professionals</a></li>
      <li><a href="#">Secretarial vaccancies</a></li>
      <li><a href="#">Experienced Lawyers</a></li>
    </ul>
  </div>
</section>

<section class="vaccancies">
  <div class="container-large">
    <div class="title_main">
      <h6>Vaccancies</h6>
      <h2>Latest Vaccancies</h2>
      <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="vaccancies_inner">
      <div class="row">
        <div class="col-lg-4 col-md-6">
          <div class="vaccancies_box">
            <h5>Real Estate</h5>
            <div class="vaccancies_box_inner">
              <h4>Legal secretary, real estate department</h4>
              <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
              <ul>
                <li>Location: Stratford upon Avon</li>
                <li>Type: Full time</li>
              </ul>
              <a href="job-detail.php">Read more</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="vaccancies_box">
            <h5>Real Estate</h5>
            <div class="vaccancies_box_inner">
              <h4>Non-contentious construction lawyer</h4>
              <p>We're hiring for an exciting opportunity for a non-contentious construction lawyer to provide professional support to a partner,...</p>
              <ul>
                <li>Location: Stratford upon Avon</li>
                <li>Type: Full time</li>
              </ul>
              <a href="job-detail.php">Read more</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="vaccancies_box">
            <h5>Town and Country Homes</h5>
            <div class="vaccancies_box_inner">
              <h4>Legal secretary, Town and Country Homes team</h4>
              <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
              <ul>
                <li>Location: Stratford upon Avon</li>
                <li>Type: Full time</li>
              </ul>
              <a href="job-detail.php">Read more</a>
            </div>
          </div>
        </div>
      </div>
      <a href="job-listing.php" class="view_all">View all</a>
    </div>
  </div>
</section>

<section class="about_wrapp_one p-0">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-7">
        <div class="about_wrapp_one_inner">
          <h2 class="text-white">CPR</h2>
          <p class="text-white">Fusce ac felis sit amet ligula pharetra condimentum. In hac habitasse platea dictumst. Fusce fermentum odio nec arcu. Sed a libero. Etiam imperdiet imperdiet orci.</p>
          <a href="#" class="btn_pink2">Find out more</a>
        </div>
      </div>
      <div class="col-md-5">
        <div class="about_wrapp_one_img">
          <img src="images/cpr.png" alt="">
        </div>
      </div>
    </div>
  </div>
</section>

<section class="value_wrapp second">
  <div class="container-large">
    <div class="title_main">
      <h6 class="text-white">Values</h6>
      <h2 class="text-white">What we stand for</h2>
    </div>
  </div>
  <div class="container-small">
    <div class="value_main">
      <div class="value_box">
        <p class="number text-white">1.</p>
        <h3 class="text-white">Phasellus a est</h3>
        <p class="text-white">Phasellus viverra nulla ut metus varius laoreet. Phasellus consectetuer vestibulum elit. In turpis. Duis vel nibh at velit </p>
        <p class="text-white">Quisque ut nisi. Nulla sit amet est. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Mauris turpis nunc, blandit et, volutpat molestie, porta ut, ligula. Aliquam erat volutpat.</p>
      </div>
      <div class="value_box">
        <p class="number text-white">2.</p>
        <h3 class="text-white">Fusce egestas elit eget</h3>
        <p class="text-white">Suspendisse non nisl sit amet velit hendrerit rutrum. Fusce pharetra convallis urna. In turpis. Sed lectus.</p>
        <p class="text-white">Fusce neque. Aenean massa. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Etiam ut purus mattis mauris sodales aliquam. Aliquam eu nunc.</p>
      </div>
      <div class="value_box">
        <p class="number text-white">3.</p>
        <h3 class="text-white">Donec</h3>
        <p class="text-white">Phasellus gravida semper nisi. Sed hendrerit. Etiam rhoncus. Phasellus gr</p>
        <p class="text-white">Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Donec sodales sagittis magna. Phasellus blandit leo ut odio. Aenean commodo ligula eget dolor. Sed consequat, leo eget bibendum sodales, augue</p>
      </div>
      <div class="value_box">
        <p class="number text-white">4.</p>
        <h3 class="text-white">Fusce egestas elit eget</h3>
        <p class="text-white">Suspendisse non nisl sit amet velit hendrerit rutrum. Fusce pharetra convallis urna. In turpis. Sed lectus.</p>
        <p class="text-white">Fusce neque. Aenean massa. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Etiam ut purus mattis mauris sodales aliquam. Aliquam eu nunc.</p>
      </div>
    </div>
  </div>
</section>

    <section class="about_wrapp_one second">
        <div class="container-medium">
            <div class="row align-items-center">
                <div class="col-md-5 order-md-1 order-2">
                    <div class="about_wrapp_one_img">
                        <img src="images/history.png" alt="">
                    </div>
                </div>
                <div class="col-md-7 order-md-2 order-1">
                    <div class="about_wrapp_one_inner">
                        <h2 class="text-white">Trainee Solicitors</h2>
                        <p class="text-white">Duis leo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Suspendisse feugiat. Fusce commodo aliquam arcu.</p>
                        <a href="#" class="btn_pink2">Read more</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


<section class="careers_location">
  <div class="row align-items-center">
    <div class="col-md-5">
      <div class="careers_location_text">
        <div class="title_main">
          <h6>Locations</h6>
          <h2>Great locations</h2>
          <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
    </div>
    <div class="col-md-7">
      <div class="locatio_map">
        <img src="images/map-bg.png" alt="">
      </div>
    </div>
  </div>
</section>

<section class="instagram_wrapp">
  <div class="container-medium">
    <div class="title_main">
      <h6>Instagram</h6>
      <h2>Discover more through our instagram account</h2>
    </div>
    <div class="row">
      <div class="col-md-3 col-6">
        <div class="instagram_post">
          <a href="#"><img src="images/insta1.png" alt=""></a>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="instagram_post">
          <a href="#"><img src="images/insta2.png" alt=""></a>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="instagram_post">
          <a href="#"><img src="images/insta3.png" alt=""></a>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="instagram_post">
          <a href="#"><img src="images/insta4.png" alt=""></a>
        </div>
      </div>
    </div>
    <a href="#" class="btn_pink">Discover more</a>
  </div>
</section>



</main>

<?php
include "include/footer.php";
?>
      