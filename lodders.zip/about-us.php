<?php
include "include/header.php";
?>

<main>

<section class="about_section">
  <div class="row align-items-center">
    <div class="col-md-6">
      <div class="about_section_text">
        <h1>About Lodders</h1>
        <p>Sed a libero. Pellentesque auctor neque nec urna. Pellentesque dapibus hendrerit tortor. Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi. Fusce risus nisl, viverra et, tempor et, pretium in, sapien.</p>
        <p>Donec venenatis vulputate lorem. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Duis lobortis massa imperdiet quam. Donec id justo. Nam pretium turpis et arcu.</p>
        <p>Pellentesque libero tortor, tincidun</p>
        <a href="#" class="btn_pink">Why work for Lodders</a>
      </div>
    </div>
    <div class="col-md-6">
      <div class="about_section_img">
        <img src="images/about-img.png" alt="">
      </div>
    </div>
  </div>
</section>

<section class="about_wrapp third">
  <div class="container-small">
    <div class="about_wrapp_inner">
      <p>Proin viverra, ligula sit amet ultrices semper, ligula arcu tristique sapien, a accumsan nisi mauris ac eros. Donec vitae orci sed dolor rutrum auctor. Quisque id mi. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Etiam rhoncus.</p>
      <p>Phasellus accumsan cursus velit. In turpis. Praesent metus tellus, elementum eu, semper a, adipiscing nec, purus. Donec id justo. Phasellus ullamcorper ipsum rutrum nunc.</p>
      <p>Curabitur a felis in nunc fringilla tristique. Vestibulum eu odio. Fusce neque. Phasellus tempus. Vivamus quis mi.</p>
    </div>
      <div class="about_wrapp_bottom">
        <div class="row">
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>200 +</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>10</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>Top 100</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>

<section class="awards_wrapp_text second">
  <div class="container-large">
    <div class="row justify-content-end">
      <div class="col-md-6">
        <div class=" ps-5">
          <h3>Etiam imperdiet imperdiet orci. Ut varius tincidunt libero.</h3>
          <p>Mr John smith</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="contact_wrapp_main">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-6">
        <div class="title_main">
          <h6>Contact us</h6>
          <h2>Need more advice?</h2>
          <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="contact_wrapp_main_img">
          <img src="images/contact-wrapp.png" alt="">
          <div class="contact_box p-4">
            <h3>Contact a member of the team</h3>
            <div class="row align-items-end">
              <div class="col-md-6">
                <ul>
                  <li>T <a href="tel:012345 6789">012345 6789</a></li>
                  <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                </ul>
              </div>
              <div class="col-md-6 text-end">
                <a href="contact-us.php" class="btn_pink2">Contact Us</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="value_wrapp">
  <div class="container-large">
    <div class="title_main">
      <h6 class="text-white">Values</h6>
      <h2 class="text-white">What we stand for</h2>
    </div>
  </div>
  <div class="container-small">
    <div class="value_main">
      <div class="value_box">
        <p class="number text-white">1.</p>
        <h3 class="text-white">Phasellus a est</h3>
        <p class="text-white">Phasellus viverra nulla ut metus varius laoreet. Phasellus consectetuer vestibulum elit. In turpis. Duis vel nibh at velit </p>
        <p class="text-white">Quisque ut nisi. Nulla sit amet est. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Mauris turpis nunc, blandit et, volutpat molestie, porta ut, ligula. Aliquam erat volutpat.</p>
      </div>
      <div class="value_box">
        <p class="number text-white">2.</p>
        <h3 class="text-white">Fusce egestas elit eget</h3>
        <p class="text-white">Suspendisse non nisl sit amet velit hendrerit rutrum. Fusce pharetra convallis urna. In turpis. Sed lectus.</p>
        <p class="text-white">Fusce neque. Aenean massa. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Etiam ut purus mattis mauris sodales aliquam. Aliquam eu nunc.</p>
      </div>
      <div class="value_box">
        <p class="number text-white">3.</p>
        <h3 class="text-white">Donec</h3>
        <p class="text-white">Phasellus gravida semper nisi. Sed hendrerit. Etiam rhoncus. Phasellus gr</p>
        <p class="text-white">Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Donec sodales sagittis magna. Phasellus blandit leo ut odio. Aenean commodo ligula eget dolor. Sed consequat, leo eget bibendum sodales, augue</p>
      </div>
      <div class="value_box">
        <p class="number text-white">4.</p>
        <h3 class="text-white">Fusce egestas elit eget</h3>
        <p class="text-white">Suspendisse non nisl sit amet velit hendrerit rutrum. Fusce pharetra convallis urna. In turpis. Sed lectus.</p>
        <p class="text-white">Fusce neque. Aenean massa. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Etiam ut purus mattis mauris sodales aliquam. Aliquam eu nunc.</p>
      </div>
    </div>
  </div>
</section>

<section class="about_wrapp_one">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-7">
        <div class="about_wrapp_one_inner">
          <h2 class="text-white">CPR</h2>
          <p class="text-white">Fusce ac felis sit amet ligula pharetra condimentum. In hac habitasse platea dictumst. Fusce fermentum odio nec arcu. Sed a libero. Etiam imperdiet imperdiet orci.</p>
          <a href="#" class="btn_pink2">Find out more</a>
        </div>
      </div>
      <div class="col-md-5">
        <div class="about_wrapp_one_img">
          <img src="images/cpr.png" alt="">
        </div>
      </div>
    </div>
  </div>
</section>

<section class="about_wrapp_one second pt-0">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-5 order-md-1 order-2">
        <div class="about_wrapp_one_img">
          <img src="images/history.png" alt="">
        </div>
      </div>
      <div class="col-md-7 order-md-2 order-1">
        <div class="about_wrapp_one_inner">
          <h2 class="text-white">Our history</h2>
          <p class="text-white">Duis leo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Suspendisse feugiat. Fusce commodo aliquam arcu.</p>
          <a href="#" class="btn_pink2">Read more</a>
        </div>
      </div>
    </div>
  </div>
</section>



</main>

<?php
include "include/footer.php";
?>
      