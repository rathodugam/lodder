<?php
include "include/header.php";
?>

<main>

<section class="inner_banner">
  <div class="container-medium">
    <h1 class="text-center text-white mb-4">Current vacancies</h1>
    <div class="people_search">
      <form action="">
        <ul>
          <li>
            <select name="name" id="Name" class="form-select">
              <option value="1">Location</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </li>
          <li>
            <p>And/or</p>
          </li>
          <li>
            <select name="Experise" id="Experise" class="form-select">
              <option value="1">Job type</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </li>
          <li>
            <a href="#" class="btn_pink">Search</a>
          </li>
        </ul>
      </form>
    </div>
  </div>
</section>

<section class="people_wrapp">
  <div class="container-medium">
    <div class="result_show mb-3">
      <p>20 results</p>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Real Estate</h5>
          <div class="vaccancies_box_inner">
            <h4>Legal secretary, real estate department</h4>
            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
       <div class="vaccancies_box">
          <h5>Real Estate</h5>
          <div class="vaccancies_box_inner">
            <h4>Non-contentious construction lawyer</h4>
            <p>We're hiring for an exciting opportunity for a non-contentious construction lawyer to provide professional support to a partner,...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Town and Country Homes</h5>
          <div class="vaccancies_box_inner">
            <h4>Legal secretary, Town and Country Homes team</h4>
            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Town and Country Homes</h5>
          <div class="vaccancies_box_inner">
            <h4>Legal secretary, Town and Country Homes team</h4>
            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>IT</h5>
          <div class="vaccancies_box_inner">
            <h4>IT Technician, IT team</h4>
            <p>We are hiring an IT technician to work as part of a small IT team to provide support across the firm on a number of IT matters...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Real Estate</h5>
          <div class="vaccancies_box_inner">
            <h4>Legal secretary, real estate department</h4>
            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>IT</h5>
          <div class="vaccancies_box_inner">
            <h4>IT Technician, IT team</h4>
            <p>We are hiring an IT technician to work as part of a small IT team to provide support across the firm on a number of IT matters...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Real Estate</h5>
          <div class="vaccancies_box_inner">
            <h4>Legal secretary, real estate department</h4>
            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="vaccancies_box">
          <h5>Real Estate</h5>
          <div class="vaccancies_box_inner">
            <h4>Non-contentious construction lawyer</h4>
            <p>We're hiring for an exciting opportunity for a non-contentious construction lawyer to provide professional support to a partner,...</p>
            <ul>
              <li>Location: Stratford upon Avon</li>
              <li>Type: Full time</li>
            </ul>
            <a href="job-detail.php">Read more</a>
          </div>
        </div>
      </div>
    </div>
    <div class="pagination">
      <ul>
        <li><a href="#"><img src="images/left-black.svg" alt=""></a></li>
        <li><a href="#">1</a></li>
        <li class="active">2</li>
        <li><a href="#">3</a></li>
        <li><a href="#">...</a></li>
        <li><a href="#">20</a></li>
        <li><a href="#"><img src="images/right-black.svg" alt=""></a></li>
      </ul>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      