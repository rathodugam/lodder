<?php
include "include/header.php";
?>

<main>

<section class="inner_banner">
  <div class="container-medium">
    <h1 class="text-center text-white mb-4">Lodders team</h1>
    <div class="people_search">
      <form action="">
        <ul>
          <li>
            <select name="name" id="Name" class="form-select">
              <option value="1">Name</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </li>
          <li>
            <p>And/or</p>
          </li>
          <li>
            <select name="Experise" id="Experise" class="form-select">
              <option value="1">Experise</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </li>
          <li>
            <a href="#" class="btn_pink2">Search</a>
          </li>
        </ul>
      </form>
    </div>
  </div>
</section>

<section class="people_wrapp">
  <div class="container-medium">
    <div class="result_show mb-3">
      <p>20 results</p>
    </div>
    <div class="row">
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/caroline-nemecek.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail2.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="people_box">
          <img src="images/jane-more.png" alt="">
          <h3 class="mb-1 mt-2">Jane more</h3>
          <p class="big">Partner</p>
          <p class="post">Agricultural law, Family Law </p>
          <ul>
            <li>T<a href="#">012345 6789</a></li>
            <li>E<a href="#">email@email.com</a></li>
          </ul>
          <a href="people-detail.php" class="btn_pink">View Profile</a>
        </div>
      </div>
    </div>
    <div class="pagination">
      <ul>
        <li><a href="#"><img src="images/left-black.svg" alt=""></a></li>
        <li><a href="#">1</a></li>
        <li class="active">2</li>
        <li><a href="#">3</a></li>
        <li><a href="#">...</a></li>
        <li><a href="#">20</a></li>
        <li><a href="#"><img src="images/right-black.svg" alt=""></a></li>
      </ul>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      