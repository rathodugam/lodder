<?php
include "include/header.php";
?>

<main>

<section class="people_wrapp_top">
  <div class="row justify-content-end">
    <div class="col-lg-6 col-md-8 col-10">
      <div class="people_wrapp_top_inner">
        <h6>Associate</h6>
        <h1>Jane More</h1>
        <p class="text-white">Specialist in Agricultural Law</p>
        <ul>
          <li><a href="tel:01234 56789" class="btn_pink2">01234 56789</a></li>
          <li><a href="mailto:companymail.com" class="btn_pink2">Email</a></li>
          <li><a href="#" class="vcard">+ VCARD</a></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="people_detail_one">
  <div class="container-large">
    <div class="row align-items-center">
      <div class="col-md-5">
        <img src="images/jane-more2.png" alt="">
      </div>
      <div class="col-md-7">
        <div class="people_detail_one_text">
          <h2>Short bio:</h2>
          <p>I have been with Lodders since April 2001, having joined as a teenager – it was my first “proper job”. I am now the Operations Director and responsible for all of the premises across the Lodders estate, their operation, and the wellbeing of the staff who work in them.</p>
          <p>More recently, I have implemented Covid-19 related security measures and introduced associated safety precautions. I head up the business support teams, oversee the day-to-day running of our five offices, and I am the firm’s Health & Safety Officer.</p>
          <hr>
          <p class="location_leave">Located in Stratford upon Avon</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="excel_wrapp">
  <div class="container-medium">
    <h2 class="mb-4">What I excel in:</h2>
    <ul>
      <li>Agricultural law </li>
      <li>Charity Law</li>
      <li>Private Client</li>
    </ul>
  </div>
</section>

<section class="career_highlights">
  <div class="container-medium">
    <h2 class="text-white mb-4">My career highlights</h2>
    <div class="row">
      <div class="col-md-6">
        <ul>
          <li>Proin magna. Sed magna purus, fermentum eu, tincidunt eu, varius ut, felis. Curabitur a felis in nunc fringilla tristique. Curabitur a felis in nunc fringilla tristique.</li>
          <li>Vestibulum dapibus nunc ac augue. Integer ante a rcu, accumsan a, consectetuer eget, posuere ut, mauris. Nulla facilisi.</li>
          <li>Maecenas egestas arcu quis ligula mattis placerat. Aenean vulputate eleifend tellus. Morbi mattis ullamcorper velit.</li>
        </ul>
      </div>
      <div class="col-md-6">
        <ul>
          <li>Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. In hac habitasse platea dictumst. Praesent vestibulum dapibus nibh. Pellentesque libero tortor, tincidunt et, tincidunt eget, semper nec, quam.</li>
          <li>Maecenas malesuada. Cras dapibus. Curabitur at lacus ac velit ornare lobortis.</li>
          <li>Quisque libero metus, condimentum nec, tempor a, commodo mollis, magna. Cras id dui. Donec interdum, metus et hendrerit aliquet, dolor diam sagittis ligula, eget egestas libero turpis vel mi. Vivamus aliquet elit ac nisl.</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="case_study">
  <div class="container-medium">
    <div class="title_main">
      <h6>Featured</h6>
      <h2>Case study and/or related content</h2>
      <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="swiper case_stydy_slider">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
      <div class="image-slider__fraction">
        <div class="image-slider__current">1</div>
        <div class="image-slider__sepparator">/</div>
        <div class="image-slider__total">1</div>
      </div>
    </div>
  </div>
</section>

<section class="awards_wrapp">
  <div class="container-small">
    <div class="row">
      <div class="col-md-3">
        <img src="images/awards.png" alt="">
      </div>
      <div class="col-md-9">
        <div class="awards_wrapp_text ps-5">
          <h3>Etiam imperdiet imperdiet orci. Ut varius tincidunt libero.</h3>
          <p>Mr John smith</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="contact_wrapp_main">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-6">
        <div class="title_main">
          <h6>Contact us</h6>
          <h2>Need more advice?</h2>
          <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="contact_wrapp_main_img">
          <img src="images/contact-wrapp.png" alt="">
          <div class="contact_box p-4">
            <h3>Contact a member of the team</h3>
            <div class="row align-items-end">
              <div class="col-md-6">
                <ul>
                  <li>T <a href="tel:012345 6789">012345 6789</a></li>
                  <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                </ul>
              </div>
              <div class="col-md-6 text-end">
                <a href="contact-us.php" class="btn_pink2">Contact Us</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="rest_of_team">
    <div class="title_main">
      <h6>Meet the team</h6>
      <h2>The rest of my team</h2>
    </div>
    <div class="rest_of_team_slider">
      <div class="swiper team_slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/caroline-nemecek.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
        </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
      </div>
    </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      