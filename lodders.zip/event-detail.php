<?php
include "include/header.php";
?>

<main>

<section class="event_banner">
  <div class="container-large">
    <div class="breadcrumbs mb-5 pt-3">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="information-hub.php">Information Hub</a></li>
        <li><a href="information-hub.php">Events & Webinars</a></li>
        <li>Event details page</li>
      </ul>
    </div>
    <div class="container-medium">
    <div class="insight_banner_inner">
      <h1>Praesent ac massa at ligula</h1>
      <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vivamus quis mi. Etiam sit amet orci eget eros faucibus tincid</p>
      <ul class="mb-3">
        <li>Jul 27, 2021</li>
        <li>18:30</li>
        <li>London</li>
        <li>Event</li>
      </ul>
      <a href="#" class="btn_pink">Book now</a>
    </div>
    </div>
  </div>
</section>

<section class="insight_detail_wrapp second">
  <div class="container-medium">
    <div class="row">
      <div class="col-lg-8 col-md-12">
        <div class="insight_detail_in">
        <p class="big">Sed fringilla mauris sit amet nibh. Donec vitae sapien ut libero venenatis faucibus. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue</p>
        <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Pellentesque dapibus hendrerit tortor. Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Vestibulum rutrum, mi nec elementum vehicula, eros quam gravida nisl, id fringilla neque ante vel mi. Sed aliquam ultrices mauris.</p>
        <p>Phasellus accumsan cursus velit. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.</p>
        <p>Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Etiam vitae tortor. Duis lobortis massa imperdiet quam. Vestibulum ullamcorper mauris at ligula. Aenean imperdiet.</p>
        <div class="banner_video insight_video mb-4 mt-4">
          <img src="images/video-placeholder.png" alt="" class="w-100">
          <button type="button" class="video-button" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <img src="images/Play.png" alt="">
          </button>
        </div>
        <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Pellentesque dapibus hendrerit tortor. Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Vestibulum rutrum, mi nec elementum vehicula, eros quam gravida nisl, id fringilla neque ante vel mi. Sed aliquam ultrices mauris.</p>
        <p>Phasellus accumsan cursus velit. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.</p>
        <p>Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Etiam vitae tortor. Duis lobortis massa imperdiet quam. Vestibulum ullamcorper mauris at ligula. Aenean imperdiet.</p>
        <a href="contact-us.php" class="btn_pink">Book now</a>
        <div class="speaker">
          <h3 class="mb-4">Speakers</h3>
          <ul>
            <li>
              <div class="speaker_img">
                <img src="images/speaker1.png" alt="">
              </div>
              <h4>Jane Doe</h4>
              <p>Partner, Company</p>
            </li>
             <li>
              <div class="speaker_img">
                <img src="images/speaker2.png" alt="">
              </div>
              <h4>John Smith</h4>
              <p>Partner, Company</p>
            </li>
             <li>
              <div class="speaker_img">
                <img src="images/speaker3.png" alt="">
              </div>
              <h4>John Smith</h4>
              <p>Partner, Longer Company Name</p>
            </li>
             <li>
              <div class="speaker_img">
                <img src="images/speaker4.png" alt="">
              </div>
              <h4>Jane Doe</h4>
              <p>Partner, Company</p>
            </li>
          </ul>
        </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12">
        <div class="organizer_wrapp">
          <div class="organizer_info p-4">
            <div class="organizer_img">
              <img src="images/speaker1.png" alt="">
            </div>
            <h6>Keynote speaker</h6>
            <h4>Emma Sommerville</h4>
            <p class="big">Director, Company</p>
            <p>Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Mauris sollicitudin fermentum libero. Phasellus magna.</p>
          </div>
          <div class="organizer_text p-4">
            <h6>Event organiser</h6>
            <p>Anglea Howard</p>
            <ul>
              <li>T <a href="#">012345 6789</a></li>
              <li>E <a href="#">email@email.com</a></li>
            </ul>
            <hr>
            <h6>Share</h6>
            <ul class="social_share mt-3">
              <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram"></i></a></li>
              <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="#"><i class="far fa-envelope"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="event_location">
  <div class="row align-items-center">
    <div class="col-lg-6 col-md-12">
      <div class="event_location_left">
        <div class="title_main white">
          <h6>When and where</h6>
          <h2>Event Information</h2>
          <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus</p>
        </div>
        <ul class="mb-4">
          <li>
            Date <span>Jul 27, 2021</span>
          </li>
          <li>
            Time <span>16:30 - 18:30</span>
          </li>
          <li>
            Location <span>102 The Park, Main street, Coventry, CV12 4FR</span>
          </li>
        </ul>
        <a href="#" class="btn_pink2">Book now</a>
      </div>
    </div>
    <div class="col-lg-6 col-md-12">
      <div class="event_location_map">
        <img src="images/event-map.png" alt="">
      </div>
    </div>
  </div>
</section>

<section class="information_hub">
  <div class="row align-items-center">
    <div class="col-md-5 pl_50">
      <div class="information_hub_inner">
      <div class="title_main">
        <h6>Related</h6>
        <h2>Related news</h2>
        <p>Nam pretium turpis et arcu. Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Cras sagittis. Phasellus ullamcorper ipsum rutrum nunc.</p>
      </div>
      </div>
    </div>
    <div class="col-md-7">
      <div class="info_hub_slider">
        <div class="swiper info_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide2.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</section>




</main>

<?php
include "include/footer.php";
?>
      
      <div class="modal fade video_popup" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <iframe width="580" height="330" src="https://www.youtube.com/embed/9xwazD5SyVg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div> 