<?php
include "include/header.php";
?>

<main>

<section class="back pt-3 pb-3">
  <div class="container-large">
    <a href="information-hub.php">< Back</a>
  </div>
</section>

<section class="insight_banner">
  <div class="container-large">
    <div class="breadcrumbs mb-5">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="information-hub.php">Information Hub</a></li>
        <li>News Details page </li>
      </ul>
    </div>
    <div class="insight_banner_inner">
      <h1>Praesent ac massa at ligula</h1>
      <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vivamus quis mi. Etiam sit amet orci eget eros faucibus tincid</p>
      <ul>
        <li>Jane More</li>
        <li>Jul 27, 2021</li>
        <li><a href="mailto:email@email.com">email@email.com</a></li>
        <li>News</li>
      </ul>
    </div>
  </div>
  <div class="container-small">
    <div class="insight_banner_img">
      <img src="images/insight-detail.png" alt="">
    </div>
  </div>
</section>

<section class="insight_detail_wrapp">
  <div class="container-small">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <p class="big">Sed fringilla mauris sit amet nibh. Donec vitae sapien ut libero venenatis faucibus. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue</p>
        <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Pellentesque dapibus hendrerit tortor. Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Vestibulum rutrum, mi nec elementum vehicula, eros quam gravida nisl, id fringilla neque ante vel mi. Sed aliquam ultrices mauris.</p>
        <p>Phasellus accumsan cursus velit. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.</p>
        <p>Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Etiam vitae tortor. Duis lobortis massa imperdiet quam. Vestibulum ullamcorper mauris at ligula. Aenean imperdiet.</p>
        <div class="banner_video insight_video mb-4 mt-4">
          <img src="images/video-placeholder.png" alt="" class="w-100">
          <button type="button" class="video-button" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <img src="images/Play.png" alt="">
          </button>
        </div>
        <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Pellentesque dapibus hendrerit tortor. Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Vestibulum rutrum, mi nec elementum vehicula, eros quam gravida nisl, id fringilla neque ante vel mi. Sed aliquam ultrices mauris.</p>
        <p>Phasellus accumsan cursus velit. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.</p>
        <p>Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Etiam vitae tortor. Duis lobortis massa imperdiet quam. Vestibulum ullamcorper mauris at ligula. Aenean imperdiet.</p>
        <a href="contact-us.php" class="btn_pink">Contact us</a>
      </div>
    </div>
    
  </div>
</section>

<section class="contact_wrapp_main">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-6">
        <div class="title_main">
          <h6>Jane more</h6>
          <h2>About the author?</h2>
          <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="contact_wrapp_main_img">
          <img src="images/jane-more3.png" alt="">
          <div class="contact_box p-4">
            <h6>Partner</h6>
            <h3>Jane More</h3>
            <div class="row align-items-end">
              <div class="col-md-6">
                <ul>
                  <li>T <a href="tel:012345 6789">012345 6789</a></li>
                  <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                </ul>
              </div>
              <div class="col-md-6 text-end">
                <a href="people-detail.php" class="btn_pink2">View profile</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="information_hub">
  <div class="row align-items-center">
    <div class="col-md-5 pl_50">
      <div class="information_hub_inner">
      <div class="title_main">
        <h6>Related</h6>
        <h2>Related news</h2>
        <p>Nam pretium turpis et arcu. Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Cras sagittis. Phasellus ullamcorper ipsum rutrum nunc.</p>
      </div>
      </div>
    </div>
    <div class="col-md-7">
      <div class="info_hub_slider">
        <div class="swiper info_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide2.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide3.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide4.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</section>



</main>

<?php
include "include/footer.php";
?>
      
      <div class="modal fade video_popup" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <iframe width="580" height="330" src="https://www.youtube.com/embed/9xwazD5SyVg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div> 