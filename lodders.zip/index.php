<?php
include "include/header.php";
?>

<main>

<section class="banner">
  <div class="container-large">
    
  </div>
  <div class="row align-items-center">
    <div class="col-md-6">
      <div class="banner_text pl_50">
        <h1>“Grounded advice on the best way forward”</h1>
        <div class="search_form">
          <form action="">
            <input type="text" class="form-control" placeholder="Search">
            <button type="button" class="search_btn"><img src="images/search.svg" alt=""></button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="swiper banner_slider">
          <div class="swiper-wrapper">
              <div class="swiper-slide">
                  <img src="images/slide1.png" alt="">
              </div>
              <div class="swiper-slide">
                  <img src="images/slide2.png" alt="">
              </div>
          </div>
      </div>
    </div>
  </div>
   
</section>

<section class="enterprise">
  <div class="container-medium">
    <div class="title_main">
      <h6>Expertise</h6>
      <h2>What we excel in:</h2>
      <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="enterprise_inner">
      <ul>
        <li><a href="#">Agricultural law </a></li>
        <li><a href="#">Private Client</a></li>
        <li><a href="#">Real Estate Law</a></li>
        <li><a href="#">Corporate Law</a></li>
        <li><a href="#">Commercial Law</a></li>
        <li><a href="#">Dispute Resolution</a></li>
        <li><a href="#">Family Law</a></li>
        <li><a href="employment-law.php">Employment Law</a></li>
        <li><a href="#">Care and Capacity Law </a></li>
        <li><a href="#">Charity Law</a></li>
        <li><a href="#">All services A-Z</a></li>
      </ul>
    </div>
  </div>
</section>

<section class="peaple_wrapp">
  <div class="row">
    <div class="col-md-6">
      <div class="peaple_wrapp_left pe-5">
        <div class="title_main">
          <h6>People</h6>
          <h2>The people that will be there for you</h2>
          <p class="big">Aliquam erat volutpat. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Duis vel nibh at velit scelerisque suscipit.</p>
        </div>
        <div class="peaple_wrapp_form pe-5">
          <form action="">
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="Name">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <select name="" id="" class="form-select">
                    <option value="1">Expertise</option>
                    <option value="2">1</option>
                    <option value="3">2</option>
                    <option value="4">3</option>
                  </select>
                </div>
              </div>
            </div>
            <ul>
              <li><a href="#" class="btn_pink">Search</a></li>
              <li><a href="people.php">View all</a></li>
            </ul>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="peaple_wrapp_right">
        <img src="images/people.png" alt="">
        <div class="ps-4 pt-5">
          <h3 class="pb-3">Etiam imperdiet imperdiet orci. Ut varius tincidunt libero.</h3>
          <p class="big">Mr John smith</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="about_wrapp">
  <div class="container-small">
    <div class="title_main white">
      <h6>About</h6>
      <h2>We are Lodders. 200 years of working for you</h2>
      <p class="big">Aliquam erat volutpat. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Duis vel nibh at velit scelerisque suscipit.</p>
    </div>
      <a href="about-us.php" class="btn_pink2">Read More</a>
      <div class="about_wrapp_bottom">
        <div class="row">
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>200 +</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>10</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>Top 100</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>

<section class="sector_wrapp">
  <div class="row align-items-center">
    <div class="col-md-6">
      <div class="sector_wrapp_left">
        <div class="title_main">
          <h6>Sectors</h6>
          <h2>The sectors that we work in</h2>
          <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="sector_wrapp_right pr_50">
        <div class="sector_wrapp_right_inner">
          <div class="mb-4">
            <h3>Agriculture and Environment</h3>
            <p>Vestibulum facilisis, purus nec pulvinar iaculis, ligula mi congue nunc, vitae euismod ligula urna in dolor. Phasellus magna. Proin sapien ipsum, porta a, auctor quis, euismod ut, mi.</p>
          </div>
          <div class="mb-4">
            <h3>Private Wealth</h3>
            <p>Ut a nisl id ante tempus hendrerit. In hac habitasse platea dictumst. Etiam feugiat lorem non metus.</p>
          </div>
          <div class="mb-0">
            <h3>Real Estate</h3>
            <p>Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Vivamus elementum semper nisi. Nulla porta dolor. Ut leo. Praesent metus tellus, elementum eu, semper a, adipiscing nec, purus.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="information_hub">
  <div class="row align-items-center">
    <div class="col-md-5 pl_50">
      <div class="information_hub_inner">
      <div class="title_main">
        <h6>Information hub</h6>
        <h2>The thought leaders for legal services</h2>
        <p>Nam pretium turpis et arcu. Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Cras sagittis. Phasellus ullamcorper ipsum rutrum nunc.</p>
      </div>
      <a href="information-hub.php" class="btn_pink">View All</a>
      </div>
    </div>
    <div class="col-md-7">
      <div class="info_hub_slider">
        <div class="swiper info_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide2.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide3.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide4.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      