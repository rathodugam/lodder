<?php
include "include/header.php";
?>

<main>

<section class="expertise_main_banner third">
  <div class="container-medium">
    <div class="breadcrumbs mb-5">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="employment-law.php">Employment Law</a></li>
        <li><a href="employment-law-services-for-individuals.php">Employment law services for individuals</a></li>
        <li>Unfair Dismissal</li>
      </ul>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="expertise_main_banner_text">
          <h1>Unfair Dismissal</h1>
          <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Fusce commodo aliquam arcu. In ut quam vitae odio lacinia tincidunt. Donec vitae orci sed dolor rutrum auctor. Quisque id odio.</p>

          <p>Donec mollis hendrerit risus. Praesent venenatis metus at tortor pulvinar varius. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus</p>
          <a href="contact-us.php" class="btn_pink">Get in touch</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="banner_video">
          <img src="images/video-image.png" alt="">
          <button type="button" class="video-button" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <img src="images/Play.png" alt="">
          </button>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="contact_help second">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-5">
        <div class="contact_help_inner">
          <div class="title_main">
            <h6>We’re here to help</h6>
            <h2>Primary contacts</h2>
            <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
          </div>
        </div>
      </div>
      <div class="col-md-7">
        <div class="contact_help_slider">
          
          <div class="swiper contact_help_slider_in">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
          <div class="image-slider__fraction">
            <div class="image-slider__current">1</div>
            <div class="image-slider__sepparator">/</div>
            <div class="image-slider__total">1</div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="enterprise second pb-0">
  <div class="container-medium">
    <div class="title_main">
      <h6>Related</h6>
      <h2>Related expertise</h2>
    </div>
    <div class="enterprise_inner">
      <ul>
        <li><a href="#">Parental Leave </a></li>
        <li><a href="#">Discrimination</a></li>
      </ul>
    </div>
    <div class="row justify-content-end mt-5">
      <div class="col-md-6">
        <div class="awards_wrapp_text ps-5">
          <h3>Etiam imperdiet imperdiet orci. Ut varius tincidunt libero.</h3>
          <p>Mr John smith</p>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="case_study second gray_shape">
  <div class="container-medium">
    <div class="title_main">
      <h6 class="text-white">Featured</h6>
      <h2 class="text-white">Case study and/or related content</h2>
      <p class="big text-white">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="swiper case_stydy_slider">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
      <div class="image-slider__fraction">
        <div class="image-slider__current">1</div>
        <div class="image-slider__sepparator">/</div>
        <div class="image-slider__total">1</div>
      </div>
    </div>
  </div>
</section>

<section class="rest_of_team second">
    <div class="title_main">
      <h6>Meet the team</h6>
      <h2>The rest of my team</h2>
    </div>
    <div class="rest_of_team_slider">
      <div class="swiper team_slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/caroline-nemecek.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="people_box">
              <img src="images/jane-more.png" alt="">
              <h3 class="mb-1 mt-2">Jane more</h3>
              <p class="big">Partner</p>
              <p class="post">Agricultural law, Family Law </p>
              <ul>
                <li>T<a href="#">012345 6789</a></li>
                <li>E<a href="#">email@email.com</a></li>
              </ul>
              <a href="people-detail.php" class="btn_pink">View Profile</a>
            </div>
          </div>
        </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      </div>
    </div>
</section>

<section class="information_hub second">
  <div class="row align-items-center">
    <div class="col-md-5 pl_50">
      <div class="information_hub_inner">
      <div class="title_main">
        <h6>Information hub</h6>
        <h2>The thought leaders for legal services</h2>
        <p>Nam pretium turpis et arcu. Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Cras sagittis. Phasellus ullamcorper ipsum rutrum nunc.</p>
      </div>
      <a href="information-hub.php" class="btn_pink">View All</a>
      </div>
    </div>
    <div class="col-md-7">
      <div class="info_hub_slider">
        <div class="swiper info_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide2.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide3.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide4.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="faq_wrapp gray_shape">
  <div class="container-medium">
    <div class="row">
      <div class="col-md-6">
        <div class="title_main">
          <h6 class="text-white">FAQs</h6>
          <h2 class="text-white">Questions answered</h2>
          <p class="text-white">Nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                What is employment law for individuals?
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                What does an employment lawyer do?
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Why use Lodders? 
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
    

<div class="modal fade video_popup" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <iframe width="580" height="330" src="https://www.youtube.com/embed/9xwazD5SyVg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div>  
      