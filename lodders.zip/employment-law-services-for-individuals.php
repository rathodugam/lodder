<?php
include "include/header.php";
?>

<main>

<section class="expertise_main_banner second">
  <div class="container-medium">
    <div class="breadcrumbs mb-5">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="employment-law.php">Employment Law</a></li>
        <li>Employment law services for individuals</li>
      </ul>
    </div>
    <div class="row">
      <div class="col-md-8">
        <div class="expertise_main_banner_text">
          <h1>Employment law services for individuals</h1>
          <p>Lodders offers a wide range of employment law services for individuals, ranging from HR advice to advice with claims.</p>
          <a href="contact-us.php" class="btn_pink">Get in touch</a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="enterprise second">
  <div class="container-medium">
    <div class="title_main">
      <h6>Helping Employees</h6>
      <h2>Services for Individuals</h2>
    </div>
    <div class="enterprise_inner">
      <ul>
        <li><a href="unfair-dismissal.php">Unfair Dismissal </a></li>
        <li><a href="#">Parental Leave</a></li>
        <li><a href="#">Discrimination</a></li>
      </ul>
    </div>
  </div>
</section>

<section class="contact_help second">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-5">
        <div class="contact_help_inner">
          <div class="title_main">
            <h6>We’re here to help</h6>
            <h2>Primary contacts</h2>
            <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
          </div>
        </div>
      </div>
      <div class="col-md-7">
        <div class="contact_help_slider">
          
          <div class="swiper contact_help_slider_in">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
          <div class="image-slider__fraction">
            <div class="image-slider__current">1</div>
            <div class="image-slider__sepparator">/</div>
            <div class="image-slider__total">1</div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="about_wrapp second">
  <div class="container-small">
      <div class="about_wrapp_bottom">
        <div class="row">
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>200 +</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>10</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>Top 100</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>



<section class="case_study">
  <div class="container-medium">
    <div class="title_main">
      <h6>Featured</h6>
      <h2>Case study and/or related content</h2>
      <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="swiper case_stydy_slider">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3 class="text-white">Suspendisse faucibus nunc et pellentesque</h3>
                <p class="text-white">Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
      <div class="image-slider__fraction">
        <div class="image-slider__current">1</div>
        <div class="image-slider__sepparator">/</div>
        <div class="image-slider__total">1</div>
      </div>
    </div>
  </div>
</section>

<section class="information_hub">
  <div class="row align-items-center">
    <div class="col-md-5 pl_50">
      <div class="information_hub_inner">
      <div class="title_main">
        <h6>Information hub</h6>
        <h2>The thought leaders for legal services</h2>
        <p>Nam pretium turpis et arcu. Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Cras sagittis. Phasellus ullamcorper ipsum rutrum nunc.</p>
      </div>
      <a href="information-hub.php" class="btn_pink">View All</a>
      </div>
    </div>
    <div class="col-md-7">
      <div class="info_hub_slider">
        <div class="swiper info_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide2.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide3.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide4.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="info_slider_inner" style="background-image: url('images/info-slide1.png');">
                <div class="info_slider_text">
                  <h6>News</h6>
                  <h4><a href="insight-detail.php">Suspendisse non nisl sit amet velit hendrerit </a></h4>
                  <p>Vestibulum suscipit nulla quis orci. Pellentesque dapibus hendrerit tortor. Praesent egestas</p>
                  <p class="date">Aug 13, 2021</p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="faq_wrapp">
  <div class="container-medium">
    <div class="row">
      <div class="col-md-6">
        <div class="title_main">
          <h6 class="text-white">FAQs</h6>
          <h2 class="text-white">Questions answered</h2>
          <p class="text-white">Nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                What is employment law for individuals?
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                What does an employment lawyer do?
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Why use Lodders? 
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p>Employment law solicitors will often also work on employment disputes, such as unfair dismissal claims, discrimination claims (based on sex, race, disability, sexual orientation, and age), breach of contract, restrictive covenants, and whistle blowing.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      