<?php
include "include/header.php";
?>

<main>

<section class="breadcrumbs pt-3 pb-3">
  <div class="container-medium">
    <div class="breadcrumbs">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="careers.php">Careers</a></li>
        <li>Legal secretary, real estate department  </li>
      </ul>
    </div>
  </div>
</section>

<section class="job_detail_banner">
  <div class="container-medium">
    <h1>Legal secretary, real estate department</h1>
    <p>Position</p>
    <ul class="mb-3">
      <li>Real Estate</li>
      <li>Stratford upon Avon</li>
      <li>Full time</li>
    </ul>
    <a href="#" class="btn_pink">Apply now</a>
  </div>
</section>

<section class="job_detail_main">
  <div class="container-medium">
    <div class="row">
      <div class="col-md-8">
        <div class="job_detail_main_inner">
          <p>Ut varius tincidunt libero. Curabitur turpis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Donec sodales sagittis magna. Curabitur a felis in nunc fringilla tristique.</p>
          <p>Nunc nonummy metus. Maecenas nec odio et ante tincidunt tempus. Duis vel nibh at velit scelerisque suscipit. Pellentesque posuere.</p>
          <ul>
            <li>Proin magna. Sed magna purus, fermentum eu, tincidunt eu, varius ut, felis. Curabitur a felis in nunc fringilla tristique. Curabitur a felis in nunc fringilla tristique.</li>
            <li>Proin magna. Sed magna purus, fermentum eu,</li>
            <li>Nulla consequat massa quis enim. Vivamus consectetuer hendreri</li>
            <li>Proin magna. Sed magna purus, fermentum eu, tincidunt eu, varius ut, felis. Curabitur a felis in nunc fringilla tristique. Curabitur a felis in nunc fringilla tristique.</li>
          </ul>
          <p>Ut varius tincidunt libero. Curabitur turpis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Donec sodales sagittis magna. Curabitur a felis in nunc fringilla tristique.</p>
          <p>Nunc nonummy metus. Maecenas nec odio et ante tincidunt tempus. Duis vel nibh at velit scelerisque suscipit. Pellentesque posuere.</p>
          <p class="big">Lorem ipsum dolor sit</p>
          <p>Nunc nec neque. Cras risus ipsum, faucibus ut, ullamcorper id, varius ac, leo. Vestibulum suscipit nulla quis orci. In hac habitasse platea dictumst. In auctor lobortis lacus.</p>
          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse non nisl sit amet velit hendrerit rutrum. Phasellus magna. Nulla sit amet est. Pellentesque commodo eros a enim.</p>
          <p>Integer tincidunt. Nullam sagittis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce convallis metus id felis luctus adipiscing. Integer tincidunt.</p>
          <a href="#" class="btn_pink">Apply now</a>
        </div>
      </div>
      <div class="col-md-4">
        <div class="job_detail_main_right">
          <p>Closing date: <span>01 September 2021</span></p>
          <div class="job_detail_main_box">
            <h4>Why work with Lodders?</h4>
            <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis </p>
            <a href="#" class="btn_blue">Find out more</a>
          </div>
          <div class="job_detail_main_box">
            <h4>Who are Lodders?</h4>
            <p>Fusce neque. Fusce pharetra convallis urna. Fusce commodo aliquam arcu. Ut varius tincidunt libero. </p>
            <a href="#" class="btn_blue">Find out more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

    <section class="related_job">
        <div class="container-large">
            <div class="title_main">
                <h6>Realted jobs</h6>
                <h2>Other vaccines that might interest you</h2>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="vaccancies_box related">
                        <h5> Legal secretary, real estate department</h5>
                        <div class="vaccancies_box_inner">
                            <p>Are you a legal secretary with experience in property work? If so, please read on as we are recruiting for an exciting and varied...</p>
                            <ul>
                                <li>Real Estate</li>
                                <li>Stratford upon Avon</li>
                                <li>Full time</li>
                            </ul>
                            <a href="job-detail.php">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="vaccancies_box related">
                        <h5> Legal secretary, Town and Country Homes team</h5>
                        <div class="vaccancies_box_inner">
                            <p>We have an exciting vacancy for a legal secretary to join our Town and Country Homes team. This role is suited to an experienced...</p>
                            <ul>
                                <li>Real Estate</li>
                                <li>Stratford upon Avon</li>
                                <li>Full time</li>
                            </ul>
                            <a href="job-detail.php">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="vaccancies_box related">
                        <h5> IT Technician, IT team</h5>
                        <div class="vaccancies_box_inner">
                            <p>We are hiring an IT technician to work as part of a small IT team to provide support across the firm on a number of IT matters...</p>
                            <ul>
                                <li>Real Estate</li>
                                <li>Stratford upon Avon</li>
                                <li>Full time</li>
                            </ul>
                            <a href="job-detail.php">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<?php
include "include/footer.php";
?>
      
      