<?php
include "include/header.php";
?>

<main>

<section class="expertise_main_banner">
  <div class="container-medium">
    <div class="breadcrumbs mb-5">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li>Employment Law</li>
      </ul>
    </div>
    <div class="row">
      <div class="col-md-8">
        <div class="expertise_main_banner_text">
          <h1>Employment Law</h1>
          <p>Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Fusce commodo aliquam arcu. In ut quam vitae odio lacinia tincidunt. Donec vitae orci sed dolor rutrum auctor. Quisque id odio.</p>
          <p>Donec mollis hendrerit risus. Praesent venenatis metus at tortor pulvinar varius. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. In auctor lobortis lacus.</p>
          <a href="contact-us.php" class="btn_pink">Get in touch</a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="law_services">
  <div class="container-medium">
    <div class="title_main">
      <h6>Our Employment Law services</h6>
      <h2>For both employers and employees</h2>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="law_services_inner">
          <h4><a href="employment-law-services-for-individuals.php">Employment law services for individuals</a></h4>
          <ul>
            <li><a href="unfair-dismissal.php">Unfair Dismissal</a></li>
            <li><a href="#">Parental Leave</a></li>
            <li><a href="#">Discrimination</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="law_services_inner">
          <h4><a href="#">Employment Law for employers</a></h4>
          <ul>
            <li><a href="#">Settlements</a></li>
            <li><a href="#">Contracts</a></li>
            <li><a href="#">Restrictive covenants</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="about_wrapp second">
  <div class="container-small">
      <div class="about_wrapp_bottom">
        <div class="row">
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>200 +</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>10</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="about_wrapp_bottom_inner">
              <h2>Top 100</h2>
              <p>Companies to work for 2019</p>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>

<section class="awards_wrapp second">
    <div class="row align-items-center">
      <div class="col-md-6">
        <div class="awards_wrapp_img">
          <img src="images/contact-wrapp.png" alt="">
        </div>
      </div>
      <div class="col-md-6">
        <div class="awards_wrapp_text ps-5 pr_50 mt-5">
          <h3>Etiam imperdiet imperdiet orci. Ut varius tincidunt libero.</h3>
          <p>Mr John smith</p>
          <img src="images/awards.png" alt="">
        </div>
      </div>
    </div>
</section>

<section class="contact_help">
  <div class="container-medium">
    <div class="row align-items-center">
      <div class="col-md-5">
        <div class="contact_help_inner">
          <div class="title_main">
            <h6>We’re here to help</h6>
            <h2>Primary contacts</h2>
            <p>Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
          </div>
        </div>
      </div>
      <div class="col-md-7">
        <div class="contact_help_slider">
          
          <div class="swiper contact_help_slider_in">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="contact_wrapp_main_img">
                  <img src="images/caroline-nemecek-big.png" alt="">
                  <div class="contact_box p-4">
                    <h6>Partner</h6>
                    <h3>Caroline Nemecek</h3>
                    <div class="row align-items-end">
                      <div class="col-md-8">
                        <ul>
                          <li>T <a href="tel:012345 6789">012345 6789</a></li>
                          <li>M <a href="#">07123456789</a></li>
                          <li>E <a href="mailto:email@email.com">email@email.com</a></li>
                        </ul>
                      </div>
                      <div class="col-md-4 text-end">
                        <a href="people-detail.php" class="btn_pink2">View profile</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="image-slider__fraction">
              <div class="image-slider__current">1</div>
              <div class="image-slider__sepparator">/</div>
              <div class="image-slider__total">1</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="case_study second">
  <div class="container-medium">
    <div class="title_main">
      <h6 class="text-white">Featured</h6>
      <h2 class="text-white">Case study and/or related content</h2>
      <p class="big text-white">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
    </div>
    <div class="swiper case_stydy_slider">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="case_stydy_slider_img">
                <img src="images/case-study1.png" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <div class="case_stydy_slider_inner">
                <h6>Case study</h6>
                <h3>Suspendisse faucibus nunc et pellentesque</h3>
                <p>Nam pretium turpis et arcu. Nullam dictum felis eu pede mollis pretium. Quisque rutrum. Maecenas nec odio et ante tincidunt tempus. </p>
                <a href="#">Read more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
      <div class="image-slider__fraction">
        <div class="image-slider__current">1</div>
        <div class="image-slider__sepparator">/</div>
        <div class="image-slider__total">1</div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      
      