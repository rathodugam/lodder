<?php
include "include/header.php";
?>

<main>

<section class="contact_us">
  <div class="container-medium">
    <div class="row">
      <div class="col-md-6">
        <div class="contact_us_text">
          <h1>Contact us</h1>
          <p class="big">Vivamus consectetuer hendrerit lacus. Phasellus magna. Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus, vitae iaculis lacus elit id tortor. Aenean imperdiet. Nam pretium turpis et arcu.</p>
          <ul>
            <li>T <a href="#">012345 6789</a></li>
            <li>E <a href="#">help@email.com</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="contact_form">
          <form action="">
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="First Name">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="Last Name">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="Email Address">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <select name="Services" id="services" class="form-select">
                    <option value="1">Service interested in</option>
                    <option value="2">Unfair Dismissal</option>
                    <option value="3">Unfair Dismissal</option>
                    <option value="4">Discrimination</option>
                  </select>
                </div>
              </div>
              <div class="col-md-12">
                <div class="mb-3">
                  <textarea class="form-control" placeholder="Additional notes"></textarea>
                </div>
              </div>
            </div>
            <div class="submit_button">
              <button class="btn_pink">Send enquiry</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="map_wrapp">
  <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1TOMwaFvUfODsZuSFtxOybPGnK7zWw4yg" width="100%" height="490"></iframe>
</section>

<section class="office_address">
  <div class="container-medium">
    <div class="text-center">
      <h2 class="mb-5">Our offices</h2>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="office_address_inner">
          <h4>Stratford upon Avon – Lodders Solicitors</h4>
          <p>Lodders Solicitors<br>Number Ten, Elm Court<br>Arden Street<br>Stratford upon Avon<br>Warwickshire<br>CV37 6PA</p>
          <ul>
            <li>T <a href="tel:012345 6789">012345 6789</a></li>
            <li>E <a href="mailto:help@email.com">help@email.com</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="office_address_inner">
          <h4>Stratford upon Avon – Lodders Solicitors</h4>
          <p>Lodders Solicitors<br>Number Ten, Elm Court<br>Arden Street<br>Stratford upon Avon<br>Warwickshire<br>CV37 6PA</p>
          <ul>
            <li>T <a href="tel:012345 6789">012345 6789</a></li>
            <li>E <a href="mailto:help@email.com">help@email.com</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="office_address_inner">
          <h4>Cheltenham – Lodders Solicitors</h4>
          <p>Lodders Solicitors<br>Glensanda House<br>1 Montpellier Parade<br>Cheltenham<br>GL50 1UA</p>
          <ul>
            <li>T <a href="tel:012345 6789">012345 6789</a></li>
            <li>E <a href="mailto:help@email.com">help@email.com</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="office_address_inner">
          <h4>Birmingham – Lodders Solicitors</h4>
          <p>Lodders Solicitors<br>14 St Paul's Square<br>Birmingham<br>B3 1RB</p>
          <ul>
            <li>T <a href="tel:012345 6789">012345 6789</a></li>
            <li>E <a href="mailto:help@email.com">help@email.com</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

</main>

<?php
include "include/footer.php";
?>
      